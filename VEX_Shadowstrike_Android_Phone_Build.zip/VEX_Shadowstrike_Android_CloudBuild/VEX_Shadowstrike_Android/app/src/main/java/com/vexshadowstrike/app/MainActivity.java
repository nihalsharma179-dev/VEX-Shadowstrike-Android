package com.vexshadowstrike.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Gravity;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.inputmethod.EditorInfo;
import android.view.KeyEvent;

public class MainActivity extends Activity {
    private WebView webView;
    private LinearLayout startPanel;
    private EditText serverInput;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        prefs = getSharedPreferences("vex_settings", MODE_PRIVATE);
        showStartScreen();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    private void showStartScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(5, 9, 20));

        TextView title = new TextView(this);
        title.setText("VEX: SHADOWSTRIKE");
        title.setTextColor(Color.rgb(0, 229, 255));
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("TACTICAL UPGRADE  •  ANDROID CLIENT");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, dp(8), 0, dp(24));
        root.addView(subtitle, sp);

        TextView hint = new TextView(this);
        hint.setText("Enter the address of your running VEX game server. The multiplayer server must be hosted separately.");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(15);
        hint.setGravity(Gravity.CENTER);
        root.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        serverInput = new EditText(this);
        serverInput.setSingleLine(true);
        serverInput.setTextColor(Color.WHITE);
        serverInput.setHintTextColor(Color.GRAY);
        serverInput.setHint("http://192.168.1.20:3000");
        serverInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        serverInput.setImeOptions(EditorInfo.IME_ACTION_GO);
        serverInput.setText(prefs.getString("server", ""));
        serverInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        serverInput.setBackgroundColor(Color.rgb(22, 31, 48));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.setMargins(0, dp(18), 0, dp(14));
        root.addView(serverInput, ip);

        Button connect = new Button(this);
        connect.setText("CONNECT TO GAME");
        connect.setOnClickListener(v -> connectToServer());
        root.addView(connect, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this);
        note.setText("Tip: if the server runs on your computer, use its Wi-Fi IP address and keep the computer on the same network. localhost on the phone means the phone itself.");
        note.setTextColor(Color.LTGRAY);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(0, dp(22), 0, 0);
        root.addView(note, np);

        setContentView(root);
        serverInput.setOnEditorActionListener((v, actionId, event) -> { connectToServer(); return true; });
    }

    private void connectToServer() {
        String url = serverInput.getText().toString().trim();
        if (url.isEmpty()) { Toast.makeText(this, "Enter your game server address", Toast.LENGTH_LONG).show(); return; }
        if (!url.startsWith("http://") && !url.startsWith("https://")) url = "http://" + url;
        while (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        final String serverUrl = url;
        prefs.edit().putString("server", serverUrl).apply();
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 9, 20));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setSupportZoom(false);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                String baseHost = android.net.Uri.parse(serverUrl).getHost();
                return host != null && baseHost != null && !host.equals(baseHost);
            }
        });
        setContentView(webView);
        webView.loadUrl(serverUrl);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else showStartScreen();
    }
}
