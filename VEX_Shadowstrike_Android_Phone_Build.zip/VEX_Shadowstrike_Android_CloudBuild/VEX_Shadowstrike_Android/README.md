# VEX: Shadowstrike Android wrapper project

This is an Android Studio project that wraps the existing VEX: Shadowstrike web game in a full-screen WebView. It is source code for building an APK; it is **not a compiled APK**.

## Important server requirement
The game ZIP contains a Node.js + Express + Socket.IO server. The Android app does not run Node.js inside Android. You must host the server on a computer or server first, then enter its address in the app. For a computer on the same Wi-Fi, use e.g. `http://192.168.1.20:3000` (replace with your computer's real local IP). Keep the server running. For use outside your Wi-Fi, deploy it to a secure host and use HTTPS.

## Build APK with Android Studio
1. Install Android Studio and its Android SDK (API 35 platform; Gradle plugin downloads automatically).
2. Open this `VEX_Shadowstrike_Android` folder as a project.
3. Wait for Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK path, usually `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to your Android phone and install it. You may need to allow installs from your file manager.

## Notes
- App opens in landscape orientation for gameplay.
- HTTP is enabled for local-network testing. For public deployment, use HTTPS and consider disabling cleartext traffic.
- This is a wrapper around the web client, not a native game engine port.
