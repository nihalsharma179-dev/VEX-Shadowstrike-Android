PHONE-ONLY APK BUILD (GitHub Actions)

This package includes an Android wrapper project and a GitHub Actions workflow that builds a debug APK in the cloud. It does NOT include or host the Node.js multiplayer server; the app needs a separately hosted VEX game server URL.

1. In your phone browser, sign in to GitHub and create a NEW repository named VEX-Shadowstrike-Android. Set it to Private if you prefer.
2. Extract this ZIP on your phone using Files or another archive app.
3. Upload the extracted contents to the repository, preserving the folders exactly. The repository root must contain .github/workflows/build-apk.yml and the VEX_Shadowstrike_Android folder. Do not upload only the ZIP file.
4. Open the repository's Actions tab. If prompted, enable Actions.
5. Select "Build VEX Shadowstrike APK" and tap "Run workflow" (or push to main to trigger automatically).
6. Wait for the workflow to finish successfully.
7. Open the completed run, scroll to Artifacts, and download VEX-Shadowstrike-debug-APK. Extract that downloaded artifact ZIP to get app-debug.apk.
8. Tap app-debug.apk to install. If Android blocks it, allow your browser/file manager to install unknown apps for this installation, then retry.

If GitHub's mobile website does not let you upload a whole folder, switch your browser to Desktop site and upload the files/folders, or use GitHub's web editor to create the workflow and upload project files. Keep all paths intact.
